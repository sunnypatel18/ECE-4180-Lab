#include <stdio.h>
#include <phidget21.h>
#include <Windows.h>
#include <TIME.H>
#include <string.h>

CPhidgetTextLCDHandle txt_lcd = 0;
SYSTEMTIME st;

//Force = 7,Motion 6, Temp = 5
char my_date[8];
char My_sensor[12];
char Temp_sensor[12];
char Force_sensor[12];
char Motion_sensor[12];
int count;
FILE *dataFile;
double val;
char fs[13];
int i;

int CCONV AttachHandler(CPhidgetHandle TXT, void *userptr)
{

	int serialNo;
	const char *name;
	count = 0;

	CPhidget_getDeviceName (TXT, &name);
	CPhidget_getSerialNumber(TXT, &serialNo);
	printf("%s %10d attached!\n", name, serialNo);
	return 0;
}

int CCONV DetachHandler(CPhidgetHandle TXT, void *userptr)
{
	int serialNo;
	const char *name;

	CPhidget_getDeviceName (TXT, &name);
	CPhidget_getSerialNumber(TXT, &serialNo);
	printf("%s %10d detached!\n", name, serialNo);

	return 0;
}

int CCONV ErrorHandler(CPhidgetHandle TXT, void *userptr, int
					   ErrorCode, const char *Description)
{
	printf("Error handled. %d - %s\n", ErrorCode, Description);
	return 0;
}


//callback that will run if an input changes.
//Index - Index of the input that generated the event, State - boolean
//(0 or 1) representing the input state (on or off)
int CCONV InputChangeHandler(CPhidgetInterfaceKitHandle IFK, void
							 *usrptr, int Index, int State)
{
	printf("Digital Input: %d > State: %d\n", Index, State);
	return 0;
}

//callback that will run if an output changes.
//Index - Index of the output that generated the event, State -
//boolean (0 or 1) representing the output state (on or off)
int CCONV OutputChangeHandler(CPhidgetInterfaceKitHandle IFK, void
							  *usrptr, int Index, int State)
{
	printf("Digital Output: %d > State: %d\n", Index, State);
	return 0;
}

//callback that will run if the sensor value changes by more than the
//OnSensorChange trigger
//Index - Index of the sensor that generated the event, Value - the
//sensor read value
int CCONV SensorChangeHandler(CPhidgetInterfaceKitHandle IFK, void
							  *usrptr, int Index, int Value)
{

	//Display Temperature Data
	if(Index==5){
		sprintf(My_sensor, "Temp: %2.1fC", (((double) Value) * 0.2222)-61.111);
		CPhidgetTextLCD_setDisplayString (txt_lcd, 1, My_sensor);
		printf("Sensor: %d > Value: %d\n", Index, Value);}

	//Write Sensor values to respective Variables
	switch (Index) {

	case 5:

		sprintf(Temp_sensor,"Temperature=%2.1fC\n",((((double) Value) *
			0.2222)-61.111));
		break;

	case 2:
		//double val;
		val = 39.2*((double) Value) / 987.0;
		//sprintf(Force_sensor, "Force: %2.1fN", 39.2 *((double) Value) / 987.0);

		for (i = 0; (i*3) < val; i++) {
			fs[i] = '=';
		}
		CPhidgetTextLCD_setDisplayString(txt_lcd, 1, fs);
		for (i = 0; i < 13; ++i) {
			fs[i] = ' ';
		}
		break;

	case 6:
		if(Value=500)
			sprintf(Motion_sensor,"Motion=%2.1d\n",Value/4.095);
		break;
	}

	if(count>60){
		count = 0;}
	else{
		if(count==st.wSecond){
			int deleted = remove("datafile.txt");
			dataFile = fopen("datafile.txt","w+");
			count = count+10;
			fprintf(dataFile,Temp_sensor);
			fprintf(dataFile,Force_sensor);
			fprintf(dataFile,Motion_sensor);
			fclose(dataFile);
		}

	}
	//Write Data into file every 30 seconds



	return 0;
}



//Display the properties of the attached phidget to the screen.  We
//will be displaying the name, serial number and version of the attached
//device.
int display_properties(CPhidgetTextLCDHandle phid)
{
	int serialNo, version, numRows, numColumns, backlight, cursor,
		contrast, cursor_blink, numScreens;
	const char* ptr;
	CPhidget_DeviceID id;

	CPhidget_getDeviceType((CPhidgetHandle)phid, &ptr);
	CPhidget_getSerialNumber((CPhidgetHandle)phid, &serialNo);
	CPhidget_getDeviceVersion((CPhidgetHandle)phid, &version);
	CPhidget_getDeviceID((CPhidgetHandle)phid, &id);

	CPhidgetTextLCD_getRowCount (phid, &numRows);
	CPhidgetTextLCD_getColumnCount (phid, &numColumns);
	CPhidgetTextLCD_getBacklight (phid, &backlight);
	CPhidgetTextLCD_getContrast (phid, &contrast);
	CPhidgetTextLCD_getCursorOn (phid, &cursor);
	CPhidgetTextLCD_getCursorBlink (phid, &cursor_blink);

	printf("%s\n", ptr);
	printf("Serial Number: %10d\nVersion: %8d\n", serialNo, version);
	if(id == PHIDID_TEXTLCD_ADAPTER){
		CPhidgetTextLCD_getScreenCount (phid, &numScreens);
		printf("# Screens: %d\n", numScreens);
		CPhidgetTextLCD_setScreen(phid, 0);
		CPhidgetTextLCD_setScreenSize(phid,
			PHIDGET_TEXTLCD_SCREEN_2x16);
		CPhidgetTextLCD_initialize(phid);
	}

	printf("# Rows: %d\n# Columns: %d\n", numRows, numColumns);
	printf("Current Contrast Level: %d\nBacklight Status: %d\n",
		contrast, backlight);
	printf("Cursor Status: %d\nCursor Blink Status: %d\n", cursor,
		cursor_blink);

	return 0;
}

int textlcd_simple()
{
	int result;
	const char *err;

	int serialNo, version, numInputs, numOutputs, numSensors, triggerVal,
		ratiometric, i;
	const char* ptr;

	//Declare an TextLCD handle

	CPhidgetInterfaceKitHandle ifKit = 0;

	//create the TextLCD object
	CPhidgetTextLCD_create(&txt_lcd);
	CPhidgetInterfaceKit_create(&ifKit);

	//Set the handlers to be run when the device is plugged in or opened
	//from software, unplugged or closed from software, or generates an
	//error.
	CPhidget_set_OnAttach_Handler((CPhidgetHandle)txt_lcd,
		AttachHandler, NULL);
	CPhidget_set_OnDetach_Handler((CPhidgetHandle)txt_lcd,
		DetachHandler, NULL);
	CPhidget_set_OnError_Handler((CPhidgetHandle)txt_lcd,
		ErrorHandler, NULL);

	CPhidget_set_OnAttach_Handler((CPhidgetHandle)ifKit,
		AttachHandler, NULL);
	CPhidget_set_OnDetach_Handler((CPhidgetHandle)ifKit,
		DetachHandler, NULL);
	CPhidget_set_OnError_Handler((CPhidgetHandle)ifKit, ErrorHandler, NULL);
	CPhidgetInterfaceKit_set_OnInputChange_Handler (ifKit,
		InputChangeHandler, NULL);
	CPhidgetInterfaceKit_set_OnSensorChange_Handler (ifKit,
		SensorChangeHandler, NULL);
	CPhidgetInterfaceKit_set_OnOutputChange_Handler (ifKit,
		OutputChangeHandler, NULL);

	//open the TextLCD for device connections
	CPhidget_open((CPhidgetHandle)txt_lcd, -1);

	CPhidget_open((CPhidgetHandle)ifKit, -1);

	//get the program to wait for an TextLCD device to be attached
	printf("Waiting for TextLCD to be attached....\n");
	if((result =
		CPhidget_waitForAttachment((CPhidgetHandle)txt_lcd, 10000)))
	{
		CPhidget_getErrorDescription(result, &err);
		printf("Problem waiting for attachment: %s\n", err);
		return 0;
	}

	if((result = CPhidget_waitForAttachment((CPhidgetHandle)ifKit, 10000)))
	{
		CPhidget_getErrorDescription(result, &err);
		printf("Problem waiting for attachment: %s\n", err);
		return 0;
	}

	//Display the properties of the attached textlcd device
	display_properties(txt_lcd);

	CPhidget_getDeviceType((CPhidgetHandle)ifKit, &ptr);
	CPhidget_getSerialNumber((CPhidgetHandle)ifKit, &serialNo);
	CPhidget_getDeviceVersion((CPhidgetHandle)ifKit, &version);

	CPhidgetInterfaceKit_getInputCount(ifKit, &numInputs);
	CPhidgetInterfaceKit_getOutputCount(ifKit, &numOutputs);
	CPhidgetInterfaceKit_getSensorCount(ifKit, &numSensors);
	CPhidgetInterfaceKit_getRatiometric(ifKit, &ratiometric);

	//read TextLCD event data

	for(i = 0; i < numSensors; i++)
	{
		CPhidgetInterfaceKit_getSensorChangeTrigger (ifKit, i, &triggerVal);

		//printf("Sensor#: %d > Sensitivity Trigger: %d\n", i,
		//triggerVal);
	}

	while(1) {
		GetLocalTime(&st);
		sprintf(my_date, "%02d:%02d:%02d", st.wHour, st.wMinute, st.wSecond);
		CPhidgetTextLCD_setDisplayString (txt_lcd, 0, my_date);
		Sleep(900);
	}


	//all done, exit
	return 0;
}

int main(int argc, char* argv[])
{
	textlcd_simple();
	return 0;
}





