// LSM9DS90/uLCD Demo
// ECE 4180 Lab Code Template

#include "mbed.h"
#include "LSM9DS0.h"
#include "uLCD_4DGL.h"
#include <sstream>
#include "Servo.h"
#include <math.h>
#include "Speaker.h"
#include "SDFileSystem.h"
#include "Motor.h"

// uncomment this line to enable the uLCD for Part 4 of the lab
#define PART_4

// SDO_XM and SDO_G are pulled up, so our addresses are:
#define LSM9DS0_XM_ADDR  0x1D // Would be 0x1E if SDO_XM is LOW
#define LSM9DS0_G_ADDR   0x6B // Would be 0x6A if SDO_G is LOW

// refresh time. set to 500 for part 2 and 50 for part 4
#define REFRESH_TIME_MS 200

void print_accelerometer();
void print_compass_data();
void print_temperature();
void print_compass();
void print_ethernet();
void servo_speed();
void print_RS232();
void print_IR();
void play_speaker();
void write_file();
std::string read_file();

// Verify that the pin assignments below match your breadboard
LSM9DS0 imu(p9, p10, LSM9DS0_G_ADDR, LSM9DS0_XM_ADDR);
Serial pc(USBTX, USBRX);
Serial rs232(p13, p14);

#ifdef PART_4
uLCD_4DGL lcd(p28, p27, p30);
#endif

DigitalIn pb1(p25);
DigitalIn pb2(p26);
DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);
AnalogOut sensor1(p18);
AnalogIn IR(p19);

Ethernet eth;

Servo myservo(p21);
Speaker mySpeaker(p22); //PWM out

// use class to setup microSD card filesystem
SDFileSystem sd(p5, p6, p7, p8, "sd");

//Init Serial port and LSM9DS0 chip
void setup()
{
#ifdef PART_4
    lcd.baudrate(3000000);
    lcd.background_color(0);
    lcd.cls();

    lcd.printf("Initializing...");
#endif

    // Use the begin() function to initialize the LSM9DS0 library.
    // You can either call it with no parameters (the easy way):
    uint16_t status = imu.begin();

    //Make sure communication is working
    pc.printf("LSM9DS0 WHO_AM_I's returned: 0x%X\n", status);
    pc.printf("Should be 0x49D4\n\n");
}

int main()
{
    
    rs232.baud(9600);
    setup();  //Setup sensor and Serial
    pb1.mode(PullUp);
    pb2.mode(PullUp);
    led4 = 1;
    led3 = 0;
    pc.printf("------ LSM0DS0 Demo -----------\n");
    std::stringstream compass_data;
    std::string print_data;
    lcd.cls();
    set_time(1256729737);  // Set RTC time to Wed, 28 Oct 2009 11:35:37

    play_speaker();

    write_file();
    std::string file_contents = read_file();
    pc.printf(file_contents.c_str());
    while (true) {
        /*float i =0;
        for (i = 0; i < 1000000; i = i + 0.1) {
            sensor1 =( sin(i)+ 1)/2;
           
        }*/
        print_IR();
        led1 = pb1;

        led3 = !led3;

        //print_accelerometer();
        print_compass_data();
        //print_temperature();
        //print_ethernet();
        led3 = !led3;
        print_compass();
        wait_ms(REFRESH_TIME_MS);
        led4 = !led4;

    }
}
void print_accelerometer()
{
    imu.readAccel();
    pc.printf("A: x-axis: %d y-axis: %d z-axis: %d\n", imu.ax_raw, imu.ay_raw, imu.az_raw);
    rs232.printf("SERIAL PRINT -- A: x-axis: %d y-axis: %d z-axis: %d\n", imu.ax_raw, imu.ay_raw, imu.az_raw);
    //lcd.printf("Ax: %d\nAy: %d\nAz: %d\n", imu.ax_raw, imu.ay_raw, imu.az_raw);
}
void print_compass_data()
{
    imu.readMag();
    float compassHeading = imu.calcHeading();
    std::string direction = "";
    if (compassHeading > 22.5 & compassHeading <= 67.5) {
        direction = "NE";
    } else if (compassHeading > 67.5 & compassHeading <= 112.5) {
        direction = "E";
    } else if (compassHeading > 112.5 & compassHeading <= 157.5) {
        direction = "SE";
    } else if (compassHeading > 157.5 & compassHeading <= 202.5) {
        direction = "S";
    } else if (compassHeading > 202.5 & compassHeading <= 247.5) {
        direction = "SW";
    } else if (compassHeading > 247.5 & compassHeading <= 292.5) {
        direction = "W";
    } else if (compassHeading > 292.5 & compassHeading <= 337.5) {
        direction = "NW";
    } else {
        direction = "N";
    }
    pc.printf(direction.c_str());
    pc.printf("\n");
    pc.printf("Degree: %f\n", compassHeading);
    rs232.printf(direction.c_str());
    rs232.printf("\n");
    rs232.printf("SERIAL PRINT -- Degree: %f\n", compassHeading);
    //pc.printf("C: x-axis: %d y-axis: %d z-axis: %d\n", imu.mx_raw, imu.my_raw, imu.mz_raw);
    //lcd.printf("Cx: %d\nCy: %d\nCz: %d\n", imu.mx_raw, imu.my_raw, imu.mz_raw);
}
void print_temperature()
{
    imu.readTemp();
    pc.printf("T: %f C\n", imu.temperature_c);
    rs232.printf("SERIAL PRINT -- T: %f C\n", imu.temperature_c);
    rs232.putc(imu.temperature_c);
    //lcd.printf("T: %f C\n", imu.temperature_c);
}
void print_compass()
{

    float current_angle = imu.calcHeading();

    int setpoint = 75;

    int LCD_color = BLACK;
    int graphic_x=63;
    int graphic_y=90;
    int radius_1 = 29;
    int radius_2 = 33;

    lcd.filled_circle(graphic_x, graphic_y, 35, BLUE); //initial drawing

    led4=!led4;
    lcd.color(RED);
    lcd.set_font(FONT_7X8);
    lcd.text_width(1); //1X size text
    lcd.text_height(1);

    if (LCD_color != BLACK) {
        lcd.background_color(BLACK);
        lcd.textbackground_color(BLACK);
        lcd.cls();
        lcd.filled_circle(graphic_x, graphic_y, 35, BLUE);
        LCD_color = BLACK;
    }

    lcd.locate(0, 0);
    lcd.printf(" ---------------- ");
    time_t seconds = time(NULL);
    lcd.printf("|Time=%s      |", ctime(&seconds));
    lcd.printf("|                |");
    lcd.printf("|                |");
    lcd.printf(" ---------------- ");
    lcd.printf(" (COMPASS      ");
    //red line
    lcd.line(0, 50, 127, 50, 0xFF0000);
    //drawing leaf
    lcd.filled_circle(graphic_x, graphic_y + 22, 5, GREEN);
    lcd.line(graphic_x - 5, graphic_y + 25, graphic_x + 1, graphic_y + 21, BLUE);
    lcd.pixel(graphic_x + 0, graphic_y + 16, GREEN);
    lcd.pixel(graphic_x + 1, graphic_y + 17, GREEN);
    lcd.pixel(graphic_x + 1, graphic_y + 16, GREEN);
    lcd.pixel(graphic_x + 2, graphic_y + 17, GREEN);
    lcd.pixel(graphic_x + 2, graphic_y + 16, GREEN);
    lcd.pixel(graphic_x + 3, graphic_y + 17, GREEN);
    lcd.pixel(graphic_x + 3, graphic_y + 16, GREEN);
    lcd.pixel(graphic_x + 3, graphic_y + 15, GREEN);
    lcd.pixel(graphic_x + 4, graphic_y + 18, GREEN);
    lcd.pixel(graphic_x + 4, graphic_y + 17, GREEN);
    lcd.pixel(graphic_x + 4, graphic_y + 16, GREEN);
    lcd.pixel(graphic_x + 4, graphic_y + 15, GREEN);
    lcd.pixel(graphic_x + 5, graphic_y + 19, GREEN);
    lcd.pixel(graphic_x + 5, graphic_y + 18, GREEN);
    lcd.pixel(graphic_x + 5, graphic_y + 17, GREEN);
    lcd.pixel(graphic_x + 5, graphic_y + 16, GREEN);
    lcd.pixel(graphic_x + 6, graphic_y + 19, GREEN);
    lcd.pixel(graphic_x + 6, graphic_y + 18, GREEN);
    lcd.pixel(graphic_x + 6, graphic_y + 17, GREEN);
    lcd.pixel(graphic_x + 7, graphic_y + 18, GREEN);
    lcd.pixel(graphic_x + 7, graphic_y + 17, GREEN);
    lcd.pixel(graphic_x + 8, graphic_y + 18, GREEN);

    //drawing clock lines
    double angle = 2.0354;
    while (angle < 7.4248) {
        lcd.line(radius_1 * cos(angle) + graphic_x, radius_1 * sin(angle) + graphic_y, radius_2 * cos(angle) + graphic_x, radius_2 * sin(angle) + graphic_y, WHITE);
        angle +=  0.0628;

    }
    //clock arms
    double temp_angle = 2.0354 + 5.2 * (current_angle / 90.0);
    lcd.filled_rectangle((radius_1 - 1) * cos(temp_angle) + graphic_x, (radius_1 - 1) * sin(temp_angle) + graphic_y, (radius_2 + 1) * cos(temp_angle) + graphic_x, (radius_2 + 1) * sin(temp_angle) + graphic_y, WHITE);
    temp_angle = 2.0354 + 5.2 * ((double)setpoint / 90.0);
    lcd.filled_rectangle((radius_1 - 1) * cos(temp_angle) + graphic_x, (radius_1 - 1) * sin(temp_angle) + graphic_y, (radius_2 + 1) * cos(temp_angle) + graphic_x, (radius_2 + 1) * sin(temp_angle) + graphic_y, WHITE);

    //clock text

    lcd.locate(6, 10);
    lcd.color(WHITE);
    lcd.textbackground_color(BLUE);
    lcd.printf("%d MIN", abs((int) current_angle - setpoint));
    lcd.locate(7, 11);
    lcd.text_width(2); //2X size text
    lcd.text_height(2);
    lcd.printf("%2.0f", current_angle);


}
void print_ethernet()
{
    char buf[0x600];
    int size = eth.receive();
    if(size > 0) {
        eth.read(buf, size);
        printf("Destination:  %02X:%02X:%02X:%02X:%02X:%02X\n",
               buf[0], buf[1], buf[2], buf[3], buf[4], buf[5]);
        printf("Source: %02X:%02X:%02X:%02X:%02X:%02X\n",
               buf[6], buf[7], buf[8], buf[9], buf[10], buf[11]);
        std::string tempbuf(buf);
        printf(tempbuf.c_str());
    }
}
void servo_speed()
{
    float servo_speed = 0.5;
    if (!pb1) servo_speed += 0.1;
    if (!pb2) servo_speed -= 0.1;
    myservo = servo_speed;
}
void print_IR() {
    float ir_val = IR;
    std::string bar = "*";
    while (ir_val > 0) {
        bar += "*";
        ir_val -= 0.01;   
    }   
    bar += "\n";
    printf(bar.c_str());
}
void play_speaker() {
    mySpeaker.PlayNote(200.0,0.25,0.1);
}
void write_file () {
    mkdir("/sd/mydir", 0777);
    
    FILE *fp = fopen("/sd/mydir/Hello_SD_file_world.txt", "w");
    if(fp == NULL) {
        error("Could not open file for write\n");
    }
    fprintf(fp, "Hello fun SD Card World!");
    fclose(fp); 
}
std::string read_file() {
    char buffer[50];
    std::string out_buffer;
    FILE *fp = fopen("/sd/mydir/Hello_SD_file_world.txt", "r");
    if(fp == NULL) {
        error("Could not open file for read\n");
    }
    int result = 1;
    while (result > 0) {
        result = fread(buffer, 1, 50, fp);
        for (int i = 0; i < result; i++) {
            out_buffer += buffer[i];
        }
    } 
    return out_buffer;
    fclose(fp); 
}

