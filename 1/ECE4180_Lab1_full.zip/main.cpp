#include "mbed.h"
#include "PinDetect.h"
#include "Shiftbrite.h"
#include "PowerControl/PowerControl.h"
#include "PowerControl/EthernetPowerControl.h"
#include "MCP23S17.h"
#include "HSVtoRGB.h"


//#define USR_POWERDOWN    (0x104)
//int semihost_powerdown() {
//    uint32_t arg;
//    return __semihost(USR_POWERDOWN, &arg);
//}

SPI spi(p5, p6, p7);
char Opcode = 0x40;
MCP23S17 chip = MCP23S17(spi, p20, Opcode);

char Opcode2 = 0x42;
MCP23S17 chip2 = MCP23S17(spi, p20, Opcode2);

/* Use if using 2nd IO Expander */
//char Opcode2 = 0x42; // A0 goes to 3.3V instead of gnd for 2nd chip
//MCP23S17 chip2 = MCP23S17(spi, p20, Opcode2);

DigitalOut led(p21);
PwmOut led2 (p22);

PinDetect pushButton1(p8);
PinDetect pushButton2(p15);
PinDetect pushButton3(p16);

AnalogIn variable(p18);
AnalogIn variable1(p19);

// Use for debugging
Serial pc(USBTX, USBRX);

DigitalOut myled1(LED1);
DigitalOut myled2(LED2);
DigitalOut myled3(LED3);
DigitalOut myled4(LED4);

Shiftbrite myShiftbrite(p9, p10, p11, p12, p13);// ei li di n/c ci

extern "C" int switch_led(int val);

class Watchdog
{
public:
// Load timeout value in watchdog timer and enable
    void kick(float s) {
        LPC_WDT->WDCLKSEL = 0x1;                // Set CLK src to PCLK
        uint32_t clk = SystemCoreClock / 16;    // WD has a fixed /4 prescaler, PCLK default is /4
        LPC_WDT->WDTC = s * (float)clk;
        LPC_WDT->WDMOD = 0x3;                   // Enabled and Reset
        kick();
    }
// "kick" or "feed" the dog - reset the watchdog timer
// by writing this required bit pattern
    void kick() {
        LPC_WDT->WDFEED = 0xAA;
        LPC_WDT->WDFEED = 0x55;
    }
};

// Setup the watchdog timer
Watchdog wdt;

void pb1_hit_callback (void)
{
    led = !led;
}

void pb2_hit_callback (void)
{
    while(1);
}

void pb3_hit_callback (void)
{
    switch_led(led ? 0 : 1);
}

int main()
{

    // Set up push buttons
    pushButton1.mode(PullUp);
    pushButton2.mode(PullUp);
    pushButton3.mode(PullUp);
    // Wait for push button mode change
    wait(0.01);
    // Attach callbacks to pushbuttons
    pushButton1.attach_deasserted(&pb1_hit_callback);
    pushButton1.setSampleFrequency();
    pushButton2.attach_deasserted(&pb2_hit_callback);
    pushButton2.setSampleFrequency();
    pushButton3.attach_deasserted(&pb3_hit_callback);
    pushButton3.setSampleFrequency();
    
    myShiftbrite.write(0, 0, 0);

    // Start WatchDog Timer
    wdt.kick(5.0);

    // Reduce power consumption
    //PHY_PowerDown();
    //Peripheral_PowerDown(0xFFFF7FFF);

    // Setup I/O Expander Port Directions
    chip.direction(PORT_A, 0x00);
    chip.direction(PORT_B, 0xFF);
    
    chip2.direction(PORT_A, 0x00);
    chip2.direction(PORT_B, 0xFF);

    while(1) {
        myled1 = 0;
        myled2 = 1;
        myled3 = 1;
        myled4 = 0;

        led2 = variable.read();
        
        wait(0.15);
        myled1 = 1;
        myled2 = 0;
        myled3 = 0;
        myled4 = 1;
        wait(0.15);

        int hue = variable1.read()*360;
        int val = variable.read()*255;
        HSV hsv = {hue,255.0f,val};
        RGB rgb = HSV2RGB(hsv);
        myShiftbrite.write(rgb.r, rgb.g, rgb.b);

        int toggle = (int)chip.read(PORT_B);
        pc.printf("%d\n", toggle);
        chip2.write(PORT_A, toggle == 0 ? 0x00 : 0x40);

        wdt.kick();
    }
}