#include "mbed.h"

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

Ticker ticker1;
Ticker ticker2;
Ticker ticker3;
Ticker ticker4;

void tick1() {
    led1 = !led1;
}

void tick2() {
    led2 = !led2;
}

void tick3() {
    led3 = !led3;
}

void tick4() {
    led4 = !led4;
}

int main() {
    
    ticker1.attach(&tick1, 1.0);
    ticker2.attach(&tick2, 2.0);
    ticker3.attach(&tick3, 3.0);
    ticker4.attach(&tick4, 4.0);
    
    while(1) {}
}
