#include "mbed.h"
#include "rtos.h"
#include "USBHostMSD.h"
#include "wave_player.h"
#include "HSVtoRGB.h"
#include "Shiftbrite.h"
#include "uLCD_4DGL.h"

DigitalOut led1(LED1);
DigitalOut led2(LED2);

//Mutex lcd_mutex;
Mutex count_mutex;
Semaphore single(1);
AnalogIn sensor(p20);

Ticker ticker;

AnalogOut DACout(p18);
wave_player waver(&DACout);
//Shiftbrite myShiftbrite(p9, p10, p11, p12, p13);// ei li di n/c ci
uLCD_4DGL lcd(p13,p14,p30);

int count = 0;

void thread1(void const *args)
{
    // Update LCD Color
    while(true) {
        //int hue = rand()%361;
        //printf("HUE: %i\n", hue);
        //int val = rand()%256;
        //printf("VAL: %i\n", val);
        //HSV hsv = {hue,255.0f,val};
        //RGB rgb = HSV2RGB(hsv);
        //printf("1R:%f\n1G:%f\n1B:%f\n\n\n", rgb.r, rgb.g, rgb.b);
        //lcd_mutex.lock();
        //int r = ((((int)rgb.r)&0xFF) << 16);
        //int g = ((((int)rgb.g)&0xFF) << 8);
        //int b = (((int)rgb.b)&0xFF);
        //printf("R:%i\nG:%i\nB:%i\n\n\n", r, g, b);
        //single.wait();
        //int val = rand() % 0xFFFFFF;
        //lcd.background_color(val);
        //lcd_mutex.unlock();
        //single.release();
        //Thread::wait(375);
    }

}

void thread2(void const *args)
{
    // Update LCD text
    while(true) {
        //lcd_mutex.lock();
        /*single.wait();
        lcd.cls();
        lcd.color(RED);
        lcd.text_height(3);
        lcd.text_width(2);
        count_mutex.lock();
        lcd.printf("%i", count);
        count_mutex.unlock();
        single.release();
        //lcd_mutex.unlock();
        Thread::wait(100);*/
    }
}

void thread3(void const *args)
{
    // Update Shiftbrite color
    while(true) {
        int hue = rand()%361;
        int val = sensor.read()*255;
        HSV hsv = {hue,255.0f,val};
        RGB rgb = HSV2RGB(hsv);
        //myShiftbrite.write(rgb.r, rgb.g, rgb.b);
        Thread::wait(250);
    }
}

void thread4(void const *args)
{

    USBHostMSD msd("usb");

    while(1) {

        // try to connect a MSD device
        while(!msd.connect()) {
            Thread::wait(500);
        }

        // in a loop, append a file
        // if the device is disconnected, we try to connect it again
        while(1) {

            // append a file
            FILE * fp = fopen("/usb/samplenew.wav", "r");

            if (fp != NULL) {
                waver.play(fp);
                printf("Goodbye World!\r\n");
                fclose(fp);
            } else {
                printf("FILE == NULL\r\n");
            }

            Thread::wait(500);

            // if device disconnected, try to connect again
            if (!msd.connected())
                break;
        }
    }
}

void thread5(void const *args)
{
    while(true) {
        // Show video
        lcd.cls();
        lcd.media_init();
        lcd.set_sector_address(0x0000, 0x0000);
        lcd.display_video(0,0);
        led2 = !led2;

        /*lcd.cls();
        lcd.media_init();
        lcd.printf("\n\nAn SD card is needed for image and video data");
        lcd.set_sector_address(0x0000, 0x0000);
        lcd.display_image(0,0);*/
    }
}

void setup()
{
    lcd.baudrate(3000000);
    lcd.cls();
    //myShiftbrite.write(0, 0, 0);
    srand(time(NULL));
}

void increment()
{
    count_mutex.lock();
    ++count;
    count_mutex.unlock();
}

int main()
{

    setup();

    //Thread thread1task(thread1);
    //Thread thread2task(thread2);
    //Thread thread3task(thread3);
    //Thread thread4task(thread4, NULL, osPriorityNormal, 1024 * 4);
    Thread thread5task(thread5);

    ticker.attach(&increment, 1.0);

    while(1) {
        led1 = 1;
        Thread::wait(500);
        led1 = 0;
        Thread::wait(500);
    }
}
